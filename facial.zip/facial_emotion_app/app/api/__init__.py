"""
Facial Emotion Recognition Flask Application
"""
from app.factory import create_app